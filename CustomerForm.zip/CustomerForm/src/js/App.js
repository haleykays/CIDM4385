var root = document.getElementById('root');


 




ReactDOM.render(React.createElement(CustomerForm), root);
